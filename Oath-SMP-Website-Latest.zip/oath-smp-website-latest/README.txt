OATH SMP WEBSITE

Upload all HTML files together to Render as a Static Site. Set the Publish Directory to the folder containing index.html (or . if repository root).

Navigation includes Home, Oaths, Events, Recipes, and FAQ & Updates. The Oracle navigation button has been removed.
